<!-- inc/footer.php -->
<footer class="bg-dark text-white text-center p-3">
    <p>&copy; 2024 GD Hotel GmbH</p>
    <p><a href="home.php" class="text-white">Home</a> | <a href="hilfe.php" class="text-white">Help/FAQ</a>| <a href="newsletter.php" class="text-white">Newsletter</a> | <a href="impressum.php" class="text-white">Impressum</a></p>
</footer>
