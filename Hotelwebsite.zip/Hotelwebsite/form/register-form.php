<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $salutation = trim($_POST['salutation']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Prüfen, ob die Passwörter übereinstimmen
    if ($password !== $confirm_password) {
        echo '<div class="alert alert-danger" role="alert">';
        echo 'Die Passwörter stimmen nicht überein. Bitte versuchen Sie es erneut.';
        echo '</div>';
        include('../register.php');
        exit();
    }

    // Benutzer speichern (zum Beispiel in einer CSV-Datei)
    $user_file = '../user.csv';
    $new_user = [$salutation, $first_name, $last_name, $email, $username, $password];

    $file_handle = fopen($user_file, 'a');
    fputcsv($file_handle, $new_user);
    fclose($file_handle);

    // Weiterleitung bei Erfolg
    header("Location: ../home.php?success=1");
    exit();
}
?>
