<?php
    
    $host = "localhost";
    $user = "hoteladmin";
    $dbpassword = "admin";
    $database = "gd-hotels";
?>