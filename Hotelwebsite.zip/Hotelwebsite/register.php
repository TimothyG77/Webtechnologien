<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include('header.php'); ?>
<div class="container mt-5">
    <h2>Register</h2>

    <!-- Erfolgsmeldung anzeigen -->
    <?php 
    if (isset($_GET['success']) && $_GET['success'] == 1) {
        echo '<div class="alert alert-success" role="alert">';
        echo 'Die Registrierung war erfolgreich!';
        echo '</div>';
    }
    ?>

    <form action="/Webtechnologien/Hotelwebsite/form/register-form.php" method="POST" class="p-4 border rounded bg-light">
        <!-- Anrede -->
        <div class="mb-3">
            <label for="salutation" class="form-label">Anrede</label>
            <select class="form-select" id="salutation" name="salutation" required>
                <option value="">Bitte wählen...</option>
                <option value="Herr">Herr</option>
                <option value="Frau">Frau</option>
                <option value="Divers">Divers</option>
            </select>
        </div>

        <!-- Vorname -->
        <div class="mb-3">
            <label for="first_name" class="form-label">Vorname</label>
            <input type="text" class="form-control" id="first_name" name="first_name" required>
        </div>

        <!-- Nachname -->
        <div class="mb-3">
            <label for="last_name" class="form-label">Nachname</label>
            <input type="text" class="form-control" id="last_name" name="last_name" required>
        </div>

        <!-- E-Mail-Adresse -->
        <div class="mb-3">
            <label for="email" class="form-label">E-Mail-Adresse</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>

        <!-- Username -->
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>

        <!-- Passwort -->
        <div class="mb-3">
            <label for="password" class="form-label">Passwort</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>

        <!-- Passwort bestätigen -->
        <div class="mb-3">
            <label for="confirm_password" class="form-label">Passwort bestätigen</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
        </div>

        <!-- Abschicken -->
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
</div>
<?php include('footer.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
