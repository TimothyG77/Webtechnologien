<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help / FAQ</title>
    <link rel="stylesheet" href="stylesheet_bootstrap.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
<?php include('header.php'); ?>
    <header>
        <h1>Help / FAQ</h1>
        <nav>
            <ul>
                <li>
                    <a href="startseite.php">
                        <img src="images/Home-Button-Icon.jpg" alt="arial picture of the home button logo">
                    </a>
                </li>
                <li>
                    <a href="impressum.php"><img src="images/Telefon Icon.png" alt="Telefon Icon"></a>
                </li>
                <li>
                    <a href="impressum.html"><img src="images/Email Icon.png" alt="E-Mail Icon"></a>
                </li>
                <li>
                    <a href="https://www.instagram.com/"><img src="images/Instagram Icon.webp" alt="Instagram Icon"></a>
                </li>
                <li>
                    <a href="https://www.facebook.com/"><img src="images/Facebook Icon.svg" alt="Facebook Icon"></a>
                </li>
                <li>
                    <a href="login.html">Login</a>
                </li>
                <li>
                    <a href="register.html">Register</a>
                </li>
            </ul>    
        </nav>
    </header>

    <main>
        <div class="section-wrapper-help">
            <section>
                <h2>User Guide</h2>
                <p>Welcome to the GD Hotel website! Here is a quick guide on how to use the website:</p>
                <ul>
                    <li>To reserve a room you must first register. You can do this via the “Register” link on the homepage.</li>
                    <li>After registering and logging in, you can make your booking under “Reserve a room”. Here you specify the desired period and any additional services such as breakfast or parking.</li>
                    <li>You can view and manage your previous reservations at any time under “My Reservations”.</li>
                    <li>If you have any questions or need support, our customer service is available to you at any time. You can find our contact details under “Contact”.</li>
                    <li>The imprint and further information about the website can be found at the end of the page under “Imprint”.</li>
                </ul>

                <h2>How can I reserve a room?</h2>
                <p>To reserve a room, you must register and log in on our website. You can then check availability and make a booking under “Reserve a room”.</p>

                <h2>How can I cancel my reservation?</h2>
                <p>Once you are logged in, you can manage and cancel your reservations under "My Reservations".</p>

                <h2>Which payment methods are accepted?</h2>
                <p>We accept payments by credit card and PayPal. More payment methods will be added soon.</p>

                <h2>How can I contact customer service?</h2>
                <p>You can reach us by email at support@gd-hotel.at or call us by phone at +43 (0)1 234 56789.</p>

                <h2>Is there parking?</h2>
                <p>Yes, you can optionally book a parking space when booking.</p>
            </section>
        </div>
    </main>

    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <?php include('footer.php'); ?>
</body>
</html>
